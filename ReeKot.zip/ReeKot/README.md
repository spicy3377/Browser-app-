# Flutter Browser App


Author japheth jonathan


A fully created fluuter mobile browser app like chrome using inappview